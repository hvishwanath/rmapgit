/**
 * Components namespace.  These are standalone, custom components
 * APIs for widgets, decorations, flair.
 */
envision.components = envision.components || {};

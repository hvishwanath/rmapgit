envision.adapters.flotr = {};

/**
 * Adapters namespace.  These are component adapters for external
 * librares.  Envision.js ships with a Flotr2 adapter.
 */
envision.adapters = envision.adapters || {};

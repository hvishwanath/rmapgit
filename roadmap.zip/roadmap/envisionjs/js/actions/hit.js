envision.actions.hit = {
  events : [
    'hit',
    'mouseout'
  ]
};

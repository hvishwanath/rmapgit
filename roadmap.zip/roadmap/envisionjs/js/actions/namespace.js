/**
 * Actions namespace.  Actions are configurations for 
 * common use cases when building Interactions.
 */
envision.actions = envision.actions || {};

var csv = require('./node-csv/lib/csv');

var ting = csv.each('./google-weekly.csv');

var jsonData = 
[
    {date:'August 19, 2004',open:100.01,high:104.06,low:95.96,close:100.34,volume:22088000},
    {date:'August 20, 2004',open:101.48,high:109.08,low:100.50,close:108.31,volume:11377000},
    {date:'August 23, 2004',open:110.76,high:113.48,low:109.05,close:109.40,volume:9090700},
    {date:'August 24, 2004',open:111.24,high:111.60,low:103.57,close:104.87,volume:7599100},
    {date:'August 25, 2004',open:104.96,high:108.00,low:103.88,close:106.00,volume:4565900},
    {date:'August 26, 2004',open:104.95,high:107.95,low:104.66,close:107.91,volume:3527900},
    {date:'August 27, 2004',open:108.10,high:108.62,low:105.69,close:106.15,volume:3102400},
    {date:'August 30, 2004',open:105.49,high:105.49,low:102.01,close:102.01,volume:2585600},
    {date:'August 31, 2004',open:102.32,high:103.71,low:102.16,close:102.37,volume:2455900},
    {date:'September 1, 2004',open:102.70,high:102.97,low:99.67,close:100.25,volume:4525000}
];
var priceData = [[0,100.34],[1,108.31],[2,109.40],[3,104.87],[4,106.00],[5,107.91],[6,106.15],[7,102.01],[8,102.37],[9,100.25]];
var volumeData = [[0,22088000],[1,11377000],[2,9090700],[3,7599100],[4,4565900],[5,3527900],[6,3102400],[7,2585600],[8,2455900],[9,4525000]];
var summaryData = [[0,100.34],[1,108.31],[2,109.40],[3,104.87],[4,106.00],[5,107.91],[6,106.15],[7,102.01],[8,102.37],[9,100.25]];
var flagData = [[3, 'Sample Flag']];

/*
var roadmapData= [
  [
	{"rowTitle":"Holidays"}
    ,{"date":"2012/05/28","title":"Memorial Day"}
    ,{"date":"2012/07/04","title":"Independence\nDay"}
    ,{"date":"2012/09/03","title":"Labor Day"}
    ,{"date":"2012/11/22","title":"Thanksgiving"}
    ,{"date":"2012/12/25","title":"Christmas"}
  ]
  ,[
    {"rowTitle":"Events"}
    ,{"date":"2012/05/09","title":"May Event"}
    ,{"date":"2012/06/29","title":"June Event"}
    ,{"date":"2012/09/23","title":"September Event"}
  ]
  ,[
    {"rowTitle":"Milestones"}
    ,{"date":"2012/02/07","title":"Milestone 1"}
    ,{"date":"2012/06/25","title":"Milestone 2"}
    ,{"date":"2012/10/20","title":"Milestone 3"}
  ]
]
*/

var roadmapData= [
  [
	{"rowTitle":"Holidays"}
    ,{"date":"2012/05/28","title":"Memorial Day"}
    ,{"date":"2012/07/04","title":"Independence\nDay"}
    ,{"date":"2012/09/03","title":"Labor Day"}
    ,{"date":"2012/11/22","title":"Thanksgiving"}
    ,{"date":"2012/12/25","title":"Christmas"}
  ]
  ,[
    {"rowTitle":"Events"}
    ,{"date":"2012/05/09","title":"May Event"}
    ,{"date":"2012/06/29","title":"June Event"}
    ,{"date":"2012/09/23","title":"September Event"}
  ]
  ,[
    {"rowTitle":"Milestones"}
    ,{"date":"2012/02/07","title":"Milestone 1"}
    ,{"date":"2012/06/25","title":"Milestone 2"}
    ,{"date":"2012/10/20","title":"Milestone 3"}
  ]
]


function MockAdapter () {}
MockAdapter.prototype = {
  attach : function () {},
  detach : function () {},
  trigger : function () {},
  destroy : function () {}
};
